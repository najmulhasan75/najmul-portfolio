/* ==========================================================
   EDIT YOUR DETAILS HERE
   ========================================================== */
const SITE = {
  email: "nazulhasan875@gmail.com",

  // WhatsApp number in international format, digits only.
  // Bangladesh country code is 880; the leading 0 of 01307898875 is dropped.
  whatsapp: "8801307898875",
  whatsappMessage: "Hello Najmul, I found your portfolio and would like to discuss digital marketing for my business.",

  // TODO: replace the Facebook and LinkedIn addresses with your real profile links.
  // (Open your profile, copy the address from the browser, paste it here.)
  facebook: "https://www.facebook.com/search/top?q=NH%20NAJMUL",
  linkedin: "https://www.linkedin.com/search/results/people/?keywords=Najmul%20Hasan",
  instagram: "https://www.instagram.com/najmul_10_/"
};

/* ---------- Apply links ---------- */
const waUrl = `https://wa.me/${SITE.whatsapp}?text=${encodeURIComponent(SITE.whatsappMessage)}`;
document.querySelectorAll('[data-link]').forEach((el) => {
  const key = el.dataset.link;
  el.href = key === "whatsapp" ? waUrl : SITE[key];
});

/* ---------- Footer year ---------- */
document.getElementById("year").textContent = new Date().getFullYear();

/* ---------- Profile photo fallback ---------- */
const photo = document.getElementById("profilePhoto");
photo.addEventListener("error", () => {
  photo.src = "data:image/svg+xml;utf8," + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 620 620"><rect width="620" height="620" fill="#F59300"/>' +
    '<text x="310" y="350" text-anchor="middle" font-family="Arial" font-weight="800" font-size="150" fill="#111">NH</text></svg>'
  );
});

/* ---------- Mobile menu ---------- */
const menuBtn = document.getElementById("menuBtn");
const nav = document.getElementById("nav");

function setMenu(open) {
  nav.classList.toggle("open", open);
  menuBtn.setAttribute("aria-expanded", String(open));
  menuBtn.setAttribute("aria-label", open ? "Close menu" : "Open menu");
}
menuBtn.addEventListener("click", () => setMenu(!nav.classList.contains("open")));
nav.querySelectorAll("a").forEach((a) => a.addEventListener("click", () => setMenu(false)));
document.addEventListener("keydown", (e) => { if (e.key === "Escape") setMenu(false); });

/* ---------- Highlight current section in the menu ---------- */
const links = [...nav.querySelectorAll('a[href^="#"]:not(.btn)')];
const sections = links.map((a) => document.querySelector(a.getAttribute("href"))).filter(Boolean);

if ("IntersectionObserver" in window) {
  const io = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        links.forEach((a) => a.classList.toggle("active", a.getAttribute("href") === "#" + entry.target.id));
      }
    });
  }, { rootMargin: "-45% 0px -50% 0px" });
  sections.forEach((s) => io.observe(s));
}

/* ---------- Contact form (opens the visitor's email app) ---------- */
const form = document.getElementById("contactForm");
const note = document.getElementById("formNote");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const data = new FormData(form);
  const name = (data.get("name") || "").toString().trim();
  const email = (data.get("email") || "").toString().trim();
  const message = (data.get("message") || "").toString().trim();

  let valid = true;
  form.querySelectorAll("input, textarea").forEach((field) => {
    const ok = field.value.trim() !== "" && (field.type !== "email" || /^\S+@\S+\.\S+$/.test(field.value.trim()));
    field.classList.toggle("invalid", !ok);
    if (!ok) valid = false;
  });

  if (!valid) {
    note.textContent = "Please fill in your name, a valid email and your message.";
    return;
  }

  const subject = encodeURIComponent(`Project enquiry from ${name}`);
  const body = encodeURIComponent(`${message}\n\nFrom: ${name}\nReply to: ${email}`);
  window.location.href = `mailto:${SITE.email}?subject=${subject}&body=${body}`;
  note.textContent = "Your email app should open now. If it doesn’t, write to " + SITE.email + " directly.";
});
